import Expandable from '@/components/strip/Expandable';
import LikeButton from '@/components/LikeButton';
import CommentForm from '@/components/CommentForm';
import CommentList from '@/components/CommentList';
import type { PostCardData } from '@/types/post';

export default function PostCard({ post }: { post: PostCardData }) {
  return (
    <article className="card card-hover space-y-4" aria-label={post.title}>
      <header className="flex items-start justify-between gap-3">
        <h3 className="text-lg font-semibold leading-snug">{post.title}</h3>
        <span className="badge" aria-label="Tirinha" title="Formato tirinha">
          Tirinha
        </span>
      </header>

      <Expandable excerpt={post.excerpt} content={post.content} />

      <div className="flex items-center gap-3">
        <LikeButton postId={post.id} count={post.likes} />
      </div>

      <h4 id={`comentarios-${post.id}`} className="text-sm font-semibold">
        Comentários recentes
      </h4>

      <CommentList postId={post.id} />
      <CommentForm postId={post.id} />
    </article>
  );
}
