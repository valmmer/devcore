export default function About() {
  return (
    <section className="prose">
      <h1>Sobre</h1>
      <p>
        Devcore é um blog de tirinhas/histórias reais de um dev júnior — sempre
        com acessibilidade e humor.
      </p>
      <p>
        Projeto pensado para alto contraste, sem depender só de cores, e com
        foco em leitura confortável.
      </p>
    </section>
  );
}
