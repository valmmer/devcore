// src/app/(public)/posts/[slug]/page.tsx
import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import PostCard from '@/components/PostCard';

export default async function PostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug },
    select: {
      id: true,
      title: true,
      excerpt: true,
      content: true,
      likes: true,
    },
  });
  if (!post) return notFound();
  return (
    <section className="max-w-3xl mx-auto">
      <PostCard post={post} />
    </section>
  );
}
