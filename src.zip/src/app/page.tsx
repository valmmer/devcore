import { prisma } from '@/lib/prisma';
import PostCard from '@/components/PostCard';
import type { PostCardData } from '@/types/post';

export default async function Home() {
  const posts: PostCardData[] = await prisma.post.findMany({
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      title: true,
      excerpt: true,
      content: true,
      likes: true,
    },
  });

  return (
    <section className="space-y-6">
      <h1 className="text-2xl font-bold">Tirinhas do Devcore</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 items-start">
        {posts.map((p) => (
          <PostCard key={p.id} post={p} />
        ))}
      </div>
    </section>
  );
}
