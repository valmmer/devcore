// src/app/layout.tsx
import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'Devcore',
  description: 'Tirinhas de um dev júnior — acessível e divertido',
  applicationName: 'Devcore',
  icons: [{ rel: 'icon', url: '/favicon.ico' }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className="min-h-screen bg-[color:var(--surface)] text-[color:var(--text)]">
        {/* Skip link (acessibilidade teclado/leitores) */}
        <a
          href="#conteudo"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] rounded-lg px-3 py-2 bg-black/70"
        >
          Pular para o conteúdo
        </a>

        {/* Header / Navbar */}
        <header className="sticky top-0 z-50 border-b border-white/10 bg-black/20 backdrop-blur supports-[backdrop-filter]:bg-black/30">
          <nav className="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
            <Link href="/" className="text-xl font-bold leading-none">
              Devcore
            </Link>

            <ul className="flex items-center gap-6 text-sm">
              <li>
                <Link href="/" className="hover:underline underline-offset-4">
                  Início
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="hover:underline underline-offset-4"
                >
                  Sobre
                </Link>
              </li>
            </ul>
          </nav>
        </header>

        {/* Main */}
        <main id="conteudo" className="container mx-auto max-w-6xl px-4 py-8">
          {children}
        </main>

        {/* Footer */}
        <footer className="container mx-auto max-w-6xl px-4 py-10 text-center text-sm text-[color:var(--muted)]">
          © {new Date().getFullYear()} Devcore
        </footer>
      </body>
    </html>
  );
}
