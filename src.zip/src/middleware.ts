// src/middleware.ts
import { NextResponse, NextRequest } from 'next/server';

const WINDOW_MS = 60_000;
const MAX_REQ = 60;
const store = new Map<string, { count: number; ts: number }>();

export function middleware(req: NextRequest) {
  const ip = req.ip ?? req.headers.get('x-forwarded-for') ?? 'unknown';
  const now = Date.now();
  const rec = store.get(ip);
  if (!rec || now - rec.ts > WINDOW_MS) {
    store.set(ip, { count: 1, ts: now });
  } else {
    rec.count++;
    if (rec.count > MAX_REQ) {
      return new NextResponse('Too Many Requests', { status: 429 });
    }
    store.set(ip, rec);
  }
  return NextResponse.next();
}

export const config = { matcher: ['/api/:path*', '/'] };
